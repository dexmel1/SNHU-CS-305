package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController {
	private static char[] HEX_ARR = "0123456789ABCDEF".toCharArray();
	
	private String Hash(String input) {
		try {
			MessageDigest message = MessageDigest.getInstance("SHA-256");
			byte[] messageMD5 = message.digest();
			return byteHex(messageMD5);
		}
		catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return input;
	}
	
	public static String byteHex (byte[] bytes) {
		char[] hex = new char[bytes.length * 2];
		for (int i = 0; i < bytes.length; i++) {
			int j = bytes[i] & 0xFF;
			hex[i*2] = HEX_ARR[j >>> 4];
			hex[i*2+1] = HEX_ARR[j & 0x0F];
		}
		return new String(hex);
	}
	
	@RequestMapping("/hash")
	public String newHash() {
		String name = "Dexter Melton";
		String hashInfo = Hash(name);
		return "<p>Name: " + name + "</p><p> SHA-256 Cipher: " + hashInfo;
	}
}